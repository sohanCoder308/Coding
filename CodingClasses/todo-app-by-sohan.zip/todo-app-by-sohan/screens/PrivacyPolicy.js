import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import MyHeader from '../components/MyHeader'

export default class PrivacyPolicy extends Component {
  render() {
    return (
      <View style={styles.container}>
         <MyHeader title="Privacy Policy" navigation={this.props.navigation}/>
        <Text style={styles.text}> Privacy Policy </Text>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  text: {
    fontSize: 20
  }
})