import React from 'react';
import { createDrawerNavigator } from 'react-navigation-drawer';
import { AppTabNavigator } from './AppTabNavigator';
import CustomSideBarMenu from './CustomSideBarMenu';
import MyCompletedTodos from '../screens/MyCompletedTodos';
import SettingsScreen from '../screens/SettingsScreen';
import PrivacyPolicy from '../screens/PrivacyPolicy';
import NotificationsScreen from '../screens/NotificationsScreen';

export const AppDrawerNavigator = createDrawerNavigator(
  {
    Home: {
      screen: AppTabNavigator,
    },
    'Completed Todos': {
      screen: MyCompletedTodos,
    },
    Notifications: {
      screen: NotificationsScreen,
    },
    Settings: {
      screen: SettingsScreen,
    },
    'User Stories': {
      screen: PrivacyPolicy,
    },
  },
  {
    contentComponent: CustomSideBarMenu,
  },
  {
    initialRouteName: 'Home',
  }
);
