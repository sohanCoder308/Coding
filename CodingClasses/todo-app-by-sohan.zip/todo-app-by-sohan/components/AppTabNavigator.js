import React from "react";
import { StyleSheet, Image } from "react-native";
import { createBottomTabNavigator } from "react-navigation-tabs";
import { AppStackNavigator } from './AppStackNavigator';
import AddTodos from '../screens/AddTodos';
import MyRemainingTodos from '../screens/MyRemainingTodos';

export const AppTabNavigator = createBottomTabNavigator({
  AppStack: {
    screen: AppStackNavigator,
    navigationOptions: {
      tabBarIcon: (
        <Image
         source={require('../assets/todos.png')}
         style={{ width: 30, height: 28.5 }} 
        />
      ),
      tabBarLabel: 'Todos Remaining'
    },
  },
  'Add Todos': {
    screen: AddTodos,
    navigationOptions: {
      tabBarIcon: (
        <Image
         source={require('../assets/add-todo.png')}
         style={{ width: 30, height: 30 }}
        />
      ),
      tabBarLabel: 'Add Todos'
    }
  }
})